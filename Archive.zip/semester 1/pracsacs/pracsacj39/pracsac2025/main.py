from login.login import Login

if __name__ == "__main__":
    app = Login()
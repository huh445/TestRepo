find = "SHUT"
rand = "TUSH"

def make_list(data):
    result = []
    for i in data:
        result.append(i)
    return result

def find_find():
    for i in range(len(find)):
        for b in rand:
            pass